包含了两个算例
118节点算例数据来自http://motor.ece.iit.edu/data/
96rts算例来自IEEE论文
数据格式在m文件注释中给出

添加约束的脚本在Maintenance文件夹内

目标函数包括三个
1.最小检修费用
2.最大化最小备用率
3.平均备用（最小方差）
但是3需要很长的计算时间

直接运行Maintence.m

自用基于matlab及yalmip的机组检修计划模型
王砚平
2020.04